import argparse

def get_config():
    """Dynamically converts all CLI --key value pairs into a config object."""
    parser = argparse.ArgumentParser()
    args, unknown = parser.parse_known_args()
    config_dict = {}
    for i in range(0, len(unknown), 2):
        key = unknown[i].lstrip("-") # removes the '--'
        if i + 1 < len(unknown):
            config_dict[key] = unknown[i+1]
    return argparse.Namespace(**config_dict)

# backup hardcoded
# UC catalog items catalog.schema. ex. table, model
# Workspace resources do not have c.s format
def _get_config():
    return {
        "workspace_host": "https://dbc-520ddc8b-7d6b.cloud.databricks.com",
        "catalog": "electronics_catalog_dev_aloysiusdjosephaws",
        "schema": "electronics_schema",
        "table_name": "electronics_catalog_dev_aloysiusdjosephaws.electronics_schema.electronics_table", #table had internal index
        "vs_index_name": "electronics_catalog_dev_aloysiusdjosephaws.electronics_schema.electronics_table_index",        
        "metadata_volume": "/Volumes/electronics_catalog_dev_aloysiusdjosephaws/electronics_schema/ingestion_metadata",
        "model_name": "electronics_catalog_dev_aloysiusdjosephaws.electronics_schema.electronics_model",    
        "vs_endpoint_name": "electronics-VE-dev-aloysiusdjosephaws",
        "serving_endpoint_name": "electronics-SE-dev-aloysiusdjosephaws",
        "app_name": "electronics-APP-dev-aloysiusdjosephaws",
        "embedding_llm_model": "databricks-gte-large-en",
        "llm_model": "databricks-gemma-3-12b",
        "eval_llm_model": "databricks-gemma-3-12b",
        "source_path": "/Workspace/Users/aloysiusdjosephaws@gmail.com/electronics/raw_data/",
        "experiment_path": "/Users/aloysiusdjosephaws@gmail.com/electronics/experiment/",  
        "system_prompt": "You are an expert assistant. Always use tools to verify facts.",
        "llm_temperature": ".01",
        "max_tokens": "512",
        "alias": "dev",
        "workload_size": "Small",
        "token":  "dapi62dc8fb871d483f0f6e5b74774b7cf72"
    }